GET /api/projects
GraphQL: query GetProjects { projects { id name hectares } }