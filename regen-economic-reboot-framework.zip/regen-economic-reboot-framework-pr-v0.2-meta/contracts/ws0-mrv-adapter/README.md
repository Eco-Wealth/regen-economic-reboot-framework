# WS0 MRV Adapter

Placeholder contract package. See `spec.md`.
