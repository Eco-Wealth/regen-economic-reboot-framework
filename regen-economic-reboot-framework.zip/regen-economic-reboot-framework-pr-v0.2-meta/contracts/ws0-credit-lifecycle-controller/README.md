# WS0 Credit Lifecycle Controller

Placeholder contract package. See `spec.md`.
