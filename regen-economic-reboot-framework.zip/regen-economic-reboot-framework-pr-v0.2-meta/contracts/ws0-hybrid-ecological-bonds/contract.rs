// Placeholder entrypoint.
// Full CosmWasm workspace preserved under ./heb-workspace/.
