#[cfg(test)]
mod tests {
    use super::*;
    // TODO: add cw-multi-test harness tests for:
    // - instantiate
    // - deposit collateral
    // - open sale + buy
    // - repay + claim interest
    // - redeem at maturity
    // - liquidation path
}
