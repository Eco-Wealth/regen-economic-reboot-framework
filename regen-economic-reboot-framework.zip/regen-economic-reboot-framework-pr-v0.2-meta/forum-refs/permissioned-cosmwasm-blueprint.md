# permissioned-cosmwasm-blueprint.md

TODO placeholder.
