# Regen Monetary Policy v0.7-predeploy

See `docs/README.md`.
