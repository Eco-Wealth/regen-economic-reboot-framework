# Tests

Tests validate the **reference simulator** and its deterministic rounding rules.

Run:

```bash

python -m unittest discover -s tests -v

```
